package com.faisal.merchantdata

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.apache.poi.ss.usermodel.CellType
import org.apache.poi.ss.usermodel.Row
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private var allMerchants: List<Merchant> = emptyList()
    private var filtered: List<Merchant> = emptyList()
    private var headers: List<String> = Merchant.HEADERS
    private var fileName: String = "merchants.xlsx"

    private lateinit var adapter: MerchantAdapter
    private val expanded = mutableSetOf<Int>()

    private var statusFilter = "All Status"
    private var cityFilter = "All"
    private var jcsFilter = "All"
    private var volumeFilter = "All"

    private val pickFile = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            fileName = uri.lastPathSegment?.substringAfterLast('/') ?: "merchants.xlsx"
            loadExcel(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        adapter = MerchantAdapter(emptyList(), expanded)
        findViewById<RecyclerView>(R.id.recyclerMerchants).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        findViewById<Button>(R.id.btnUpload).setOnClickListener {
            pickFile.launch(arrayOf(
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "application/vnd.ms-excel",
                "*/*"
            ))
        }

        findViewById<EditText>(R.id.etSearch).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) = applyFilters()
            override fun afterTextChanged(s: Editable?) {}
        })

        findViewById<Button>(R.id.btnSearch).setOnClickListener {
            applyFilters()
            Toast.makeText(
                this,
                "${filtered.size} merchants found",
                Toast.LENGTH_SHORT
            ).show()
        }

        setupSpinner(R.id.spinnerStatus) { statusFilter = it; applyFilters() }
        setupSpinner(R.id.spinnerCity) { cityFilter = it; applyFilters() }
        setupSpinner(R.id.spinnerJcs) { jcsFilter = it; applyFilters() }
        setupSpinner(R.id.spinnerVolume) { volumeFilter = it; applyFilters() }

        findViewById<Button>(R.id.btnExportExcel).setOnClickListener { exportFiltered(share = false) }
        findViewById<Button>(R.id.btnShare).setOnClickListener { exportFiltered(share = true) }
    }

    private fun setupSpinner(id: Int, onSelect: (String) -> Unit) {
        val spinner = findViewById<Spinner>(id)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?, view: View?, position: Int, rowId: Long
            ) {
                val value = parent?.getItemAtPosition(position)?.toString() ?: "All"
                onSelect(value)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun setSpinnerItems(id: Int, items: List<String>) {
        val spinner = findViewById<Spinner>(id)
        spinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, items
        )
    }

    /** Read the chosen .xlsx file on a background thread, with progress shown. */
    private fun loadExcel(uri: Uri) {
        findViewById<ProgressBar>(R.id.progressBar).visibility = View.VISIBLE
        findViewById<TextView>(R.id.tvLoading).visibility = View.VISIBLE
        findViewById<TextView>(R.id.tvFileName).text = "Reading: $fileName"

        lifecycleScope.launch {
            try {
                val merchants = withContext(Dispatchers.IO) { parseExcel(uri) }
                allMerchants = merchants
                buildFilterDropdowns()
                updateDashboard()
                applyFilters()
                findViewById<LinearLayout>(R.id.dashboard).visibility = View.VISIBLE
                findViewById<TextView>(R.id.tvFileName).text =
                    "File: $fileName  •  ${merchants.size} merchants loaded"
                Toast.makeText(
                    this@MainActivity,
                    "${merchants.size} merchants loaded", Toast.LENGTH_SHORT
                ).show()
            } catch (e: Exception) {
                Toast.makeText(
                    this@MainActivity,
                    "Could not read this file: ${e.message}", Toast.LENGTH_LONG
                ).show()
            } finally {
                findViewById<ProgressBar>(R.id.progressBar).visibility = View.GONE
                findViewById<TextView>(R.id.tvLoading).visibility = View.GONE
            }
        }
    }

    private fun parseExcel(uri: Uri): List<Merchant> {
        val list = mutableListOf<Merchant>()
        contentResolver.openInputStream(uri)?.use { input ->
            val workbook = XSSFWorkbook(input)
            val sheet = workbook.getSheetAt(0)
            val headerRow = sheet.getRow(0) ?: return emptyList()
            val colIndex = mutableMapOf<String, Int>()
            for (cell in headerRow) {
                colIndex[cell.stringCellValue.trim()] = cell.columnIndex
            }
            headers = Merchant.HEADERS
            for (row in sheet) {
                if (row.rowNum == 0) continue
                if (isRowEmpty(row)) continue
                list.add(
                    Merchant(
                        mobile = text(row, colIndex, "Business_Mobile_Number"),
                        qrId = text(row, colIndex, "QR_identifier"),
                        registrationDateTime = text(row, colIndex, "Registration_Date_Time"),
                        city = text(row, colIndex, "City"),
                        businessName = text(row, colIndex, "Business_Name"),
                        raastVolume = number(row, colIndex, "Raast Volume"),
                        nonRaastVolume = number(row, colIndex, "Non Raast Volume"),
                        totalVolume = number(row, colIndex, "Total Volume"),
                        status = text(row, colIndex, "Status"),
                        quality = text(row, colIndex, "Quality"),
                        octVolume = number(row, colIndex, "Oct Volume"),
                        sepVolume = number(row, colIndex, "Sep Volume"),
                        jcs = text(row, colIndex, "JCS"),
                        rdm = text(row, colIndex, "RDM"),
                        address1 = text(row, colIndex, "Address1"),
                        address2 = text(row, colIndex, "Address2"),
                        landmark = text(row, colIndex, "Landmark"),
                        empId = text(row, colIndex, "Emp ID"),
                        registrationDate = text(row, colIndex, "Registration_Date_Time"),
                        name = text(row, colIndex, "Name"),
                        regMonth = text(row, colIndex, "REG_Month"),
                        jcRaastTrxAmt = number(row, colIndex, "JC_Raast_Trx_Amt_CM"),
                        obRaastTrxAmt = number(row, colIndex, "OB_Raast_Trx_Amt_CM"),
                        nonRaastTrxAmt = number(row, colIndex, "NoN_Raast_Trx_Amt_CM"),
                        quality2 = text(row, colIndex, "Quality"),
                        currentStatus = text(row, colIndex, "Current_Status"),
                        merchantGender = text(row, colIndex, "Merchant_Gender")
                    )
                )
            }
            workbook.close()
        }
        return list
    }

    private fun isRowEmpty(row: Row): Boolean {
        for (cell in row) {
            if (cell.cellType != CellType.BLANK &&
                cell.toString().isNotBlank()
            ) return false
        }
        return true
    }

    private fun text(row: Row, colIndex: Map<String, Int>, name: String): String {
        val idx = colIndex[name] ?: return ""
        val cell = row.getCell(idx) ?: return ""
        return when (cell.cellType) {
            CellType.STRING -> cell.stringCellValue.trim()
            CellType.NUMERIC -> {
                val v = cell.numericCellValue
                if (v == kotlin.math.floor(v)) v.toLong().toString() else v.toString()
            }
            CellType.BOOLEAN -> cell.booleanCellValue.toString()
            else -> cell.toString().trim()
        }
    }

    private fun number(row: Row, colIndex: Map<String, Int>, name: String): Double {
        val idx = colIndex[name] ?: return 0.0
        val cell = row.getCell(idx) ?: return 0.0
        return when (cell.cellType) {
            CellType.NUMERIC -> cell.numericCellValue
            CellType.STRING -> cell.stringCellValue.toDoubleOrNull() ?: 0.0
            else -> 0.0
        }
    }

    private fun buildFilterDropdowns() {
        val statuses = listOf("All Status") + allMerchants.map { it.currentStatus.trim() }
            .filter { it.isNotBlank() }.distinct().sorted()
        val cities = listOf("All Cities") + allMerchants.map { it.city }.filter { it.isNotBlank() }
            .distinct().sorted()
        val jcsList = listOf("All JCS") + allMerchants.map { it.jcs }.filter { it.isNotBlank() }
            .distinct().sorted()
        setSpinnerItems(R.id.spinnerStatus, statuses)
        setSpinnerItems(R.id.spinnerCity, cities)
        setSpinnerItems(R.id.spinnerJcs, jcsList)
        setSpinnerItems(
            R.id.spinnerVolume,
            listOf("All Volumes", "Total Volume = 0", "Total Volume > 0", "Total Volume ≥ 500")
        )
        cityFilter = "All Cities"; jcsFilter = "All JCS"; volumeFilter = "All Volumes"
        statusFilter = "All Status"
    }

    private fun updateDashboard() {
        val total = allMerchants.size
        val completed = allMerchants.count { it.currentStatus.trim() == "Completed" }
        val discrepant = allMerchants.count { it.currentStatus.trim() == "Discrepant" }
        val pending = allMerchants.count { it.currentStatus.trim() == "CNIC Verify Pending" }
        val totalVolume = allMerchants.sumOf { it.totalVolume }

        setStat(R.id.statTotal, total.toString(), "Total Merchants")
        setStat(R.id.statCompleted, completed.toString(), "Completed")
        setStat(R.id.statDiscrepant, discrepant.toString(), "Discrepant")
        setStat(R.id.statPending, pending.toString(), "CNIC Verify Pending")
        findViewById<TextView>(R.id.tvTotalVolume).text =
            "Total Volume (all): ${formatNumber(totalVolume)}"
    }

    private fun setStat(containerId: Int, value: String, label: String) {
        val container = findViewById<View>(containerId)
        container.findViewById<TextView>(R.id.tvStatValue).text = value
        container.findViewById<TextView>(R.id.tvStatLabel).text = label
    }

    /** All filters work together: search + status + city + JCS + volume. */
    private fun applyFilters() {
        if (allMerchants.isEmpty()) return
        val query = findViewById<EditText>(R.id.etSearch).text.toString()
            .trim().lowercase()

        filtered = allMerchants.filter { m ->
            val words = query.split("\\s+".toRegex()).filter { it.isNotBlank() }
            fun fieldMatches(field: String): Boolean =
                words.all { field.lowercase().contains(it) }
            val matchesSearch = query.isBlank() ||
                fieldMatches(m.businessName) ||
                fieldMatches(m.mobile) ||
                fieldMatches(m.qrId) ||
                fieldMatches(m.city) ||
                fieldMatches(m.address1)
            val matchesStatus = statusFilter == "All Status" ||
                m.currentStatus.trim() == statusFilter
            val matchesCity = cityFilter == "All Cities" || m.city == cityFilter
            val matchesJcs = jcsFilter == "All JCS" || m.jcs == jcsFilter
            val matchesVolume = when (volumeFilter) {
                "Total Volume = 0" -> m.totalVolume == 0.0
                "Total Volume > 0" -> m.totalVolume > 0.0
                "Total Volume ≥ 500" -> m.totalVolume >= 500.0
                else -> true
            }
            matchesSearch && matchesStatus && matchesCity && matchesJcs && matchesVolume
        }

        // Best match first: exact name, then name starting with the query,
        // then whole phrase in the name, then all words in the name,
        // then a match in mobile / QR / city / address.
        val words = query.split("\\s+".toRegex()).filter { it.isNotBlank() }
        filtered = filtered.sortedWith(
            compareByDescending<Merchant> { m ->
                val name = m.businessName.lowercase()
                when {
                    query.isBlank() -> 0
                    name == query -> 100
                    name.startsWith(query) -> 90
                    name.contains(query) -> 80
                    words.all { name.contains(it) } -> 70
                    words.any { name.contains(it) } -> 50
                    m.mobile.contains(query) || m.qrId.contains(query) ||
                        m.city.lowercase().contains(query) ||
                        m.address1.lowercase().contains(query) -> 40
                    else -> 10
                }
            }.thenBy { it.businessName.lowercase() }
        )

        adapter.update(filtered)
        findViewById<TextView>(R.id.tvFilteredCount).text =
            "Showing ${filtered.size} of ${allMerchants.size} merchants"
        findViewById<TextView>(R.id.tvEmpty).visibility =
            if (filtered.isEmpty()) View.VISIBLE else View.GONE
    }

    /** Export only the filtered rows, with all original columns, as .xlsx. */
    private fun exportFiltered(share: Boolean) {
        if (allMerchants.isEmpty()) {
            Toast.makeText(this, getString(R.string.no_file), Toast.LENGTH_SHORT).show()
            return
        }
        lifecycleScope.launch {
            try {
                val file = withContext(Dispatchers.IO) { writeExportFile() }
                val uri = FileProvider.getUriForFile(
                    this@MainActivity,
                    "com.faisal.merchantdata.fileprovider", file
                )
                if (share) {
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(intent, "Share filtered merchants"))
                } else {
                    Toast.makeText(
                        this@MainActivity,
                        "Saved: ${file.name} (${filtered.size} merchants)",
                        Toast.LENGTH_LONG
                    ).show()
                    // Open the share sheet anyway so the user can save/send it,
                    // because Downloads access varies by Android version.
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(intent, "Save / Share Excel"))
                }
            } catch (e: Exception) {
                Toast.makeText(
                    this@MainActivity,
                    "Export failed: ${e.message}", Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun writeExportFile(): File {
        val workbook = XSSFWorkbook()
        val sheet = workbook.createSheet("Filtered Merchants")
        val headerRow = sheet.createRow(0)
        headers.forEachIndexed { i, h -> headerRow.createCell(i).setCellValue(h) }
        filtered.forEachIndexed { r, m ->
            val row = sheet.createRow(r + 1)
            m.toRow().forEachIndexed { c, value ->
                val cell = row.createCell(c)
                when (value) {
                    is Double -> cell.setCellValue(value)
                    else -> cell.setCellValue(value.toString())
                }
            }
        }
        val dir = File(cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, "Filtered_Merchants_${filtered.size}.xlsx")
        FileOutputStream(file).use { workbook.write(it) }
        workbook.close()
        return file
    }

    private fun formatNumber(v: Double): String =
        if (v >= 10_000_000) {
            // Show large totals in crore, e.g. 62.68 Crore, never scientific notation
            String.format(java.util.Locale.US, "%.2f Crore", v / 10_000_000)
        } else if (v == kotlin.math.floor(v)) {
            String.format(java.util.Locale.US, "%,d", v.toLong())
        } else {
            String.format(java.util.Locale.US, "%,.2f", v)
        }
}
