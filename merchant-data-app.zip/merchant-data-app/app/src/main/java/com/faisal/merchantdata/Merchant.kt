package com.faisal.merchantdata

/** One row of the merchant Excel file. All 27 original columns are kept. */
data class Merchant(
    val mobile: String,
    val qrId: String,
    val registrationDateTime: String,
    val city: String,
    val businessName: String,
    val raastVolume: Double,
    val nonRaastVolume: Double,
    val totalVolume: Double,
    val status: String,
    val quality: String,
    val octVolume: Double,
    val sepVolume: Double,
    val jcs: String,
    val rdm: String,
    val address1: String,
    val address2: String,
    val landmark: String,
    val empId: String,
    val registrationDate: String,
    val name: String,
    val regMonth: String,
    val jcRaastTrxAmt: Double,
    val obRaastTrxAmt: Double,
    val nonRaastTrxAmt: Double,
    val quality2: String,
    val currentStatus: String,
    val merchantGender: String
) {
    /** The 27 headers in their original order, used for export. */
    companion object {
        val HEADERS = listOf(
            "Business_Mobile_Number", "QR_identifier", "Registration_Date_Time",
            "City", "Business_Name", "Raast Volume", "Non Raast Volume",
            "Total Volume", "Status", "Quality", "Oct Volume", "Sep Volume",
            "JCS", "RDM", "Address1", "Address2", "Landmark", "Emp ID",
            "Registration_Date_Time", "Name", "REG_Month",
            "JC_Raast_Trx_Amt_CM", "OB_Raast_Trx_Amt_CM",
            "NoN_Raast_Trx_Amt_CM", "Quality", "Current_Status",
            "Merchant_Gender"
        )
    }

    fun toRow(): List<Any> = listOf(
        mobile, qrId, registrationDateTime, city, businessName,
        raastVolume, nonRaastVolume, totalVolume, status, quality,
        octVolume, sepVolume, jcs, rdm, address1, address2, landmark,
        empId, registrationDate, name, regMonth, jcRaastTrxAmt,
        obRaastTrxAmt, nonRaastTrxAmt, quality2, currentStatus, merchantGender
    )
}
