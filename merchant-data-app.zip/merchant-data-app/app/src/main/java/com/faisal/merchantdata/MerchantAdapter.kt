package com.faisal.merchantdata

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class MerchantAdapter(
    private var items: List<Merchant>,
    private val expanded: MutableSet<Int>
) : RecyclerView.Adapter<MerchantAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvBusinessName: TextView = view.findViewById(R.id.tvBusinessName)
        val tvStatusChip: TextView = view.findViewById(R.id.tvStatusChip)
        val tvCity: TextView = view.findViewById(R.id.tvCity)
        val tvTotalVolume: TextView = view.findViewById(R.id.tvTotalVolume)
        val tvMobile: TextView = view.findViewById(R.id.tvMobile)
        val tvDetail: TextView = view.findViewById(R.id.tvDetail)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_merchant, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val m = items[position]
        holder.tvBusinessName.text = m.businessName.ifBlank { "(No name)" }
        holder.tvCity.text = m.city
        holder.tvTotalVolume.text = "Total Volume: ${formatNumber(m.totalVolume)}"
        holder.tvMobile.text = m.mobile
        holder.tvStatusChip.text = m.currentStatus

        val context = holder.itemView.context
        when (m.currentStatus.trim()) {
            "Completed" -> {
                holder.tvStatusChip.background =
                    ContextCompat.getDrawable(context, R.color.chip_completed)
                holder.tvStatusChip.setTextColor(
                    ContextCompat.getColor(context, R.color.chip_completed_text))
            }
            "Discrepant" -> {
                holder.tvStatusChip.background =
                    ContextCompat.getDrawable(context, R.color.chip_discrepant)
                holder.tvStatusChip.setTextColor(
                    ContextCompat.getColor(context, R.color.chip_discrepant_text))
            }
            "CNIC Verify Pending" -> {
                holder.tvStatusChip.background =
                    ContextCompat.getDrawable(context, R.color.chip_pending)
                holder.tvStatusChip.setTextColor(
                    ContextCompat.getColor(context, R.color.chip_pending_text))
            }
            else -> {
                holder.tvStatusChip.background =
                    ContextCompat.getDrawable(context, R.color.chip_pending)
                holder.tvStatusChip.setTextColor(
                    ContextCompat.getColor(context, R.color.chip_pending_text))
            }
        }

        if (expanded.contains(position)) {
            holder.tvDetail.visibility = View.VISIBLE
            holder.tvDetail.text = buildString {
                append("QR ID: ${m.qrId}\n")
                append("Mobile: ${m.mobile}\n")
                append("Address: ${m.address1}\n")
                append("Raast Volume: ${formatNumber(m.raastVolume)}  |  ")
                append("Non-Raast: ${formatNumber(m.nonRaastVolume)}\n")
                append("Oct Volume: ${formatNumber(m.octVolume)}  |  ")
                append("Sep Volume: ${formatNumber(m.sepVolume)}\n")
                append("JCS: ${m.jcs}  |  RDM: ${m.rdm}\n")
                append("Emp ID: ${m.empId}  |  Name: ${m.name}\n")
                append("REG Month: ${m.regMonth}  |  Gender: ${m.merchantGender}\n")
                append("Status: ${m.status}  |  Quality: ${m.quality}")
            }
        } else {
            holder.tvDetail.visibility = View.GONE
        }

        holder.itemView.setOnClickListener {
            if (expanded.contains(position)) expanded.remove(position)
            else expanded.add(position)
            notifyItemChanged(position)
        }
    }

    override fun getItemCount(): Int = items.size

    fun update(newItems: List<Merchant>) {
        items = newItems
        expanded.clear()
        notifyDataSetChanged()
    }

    private fun formatNumber(v: Double): String =
        if (v == kotlin.math.floor(v)) v.toLong().toString() else v.toString()
}
