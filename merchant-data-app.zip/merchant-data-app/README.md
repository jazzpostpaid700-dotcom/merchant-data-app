# Merchant Data App

An Android app for merchant onboarding work. Upload a merchant Excel file
(`.xlsx`, e.g. the daily Raw Data file), then search, filter and export the
merchants — all on the phone. No merchant data is bundled in the app and
nothing is uploaded to a server; the file you pick stays on your phone.

## What it does

- **Upload Excel at runtime** — tap "Choose Excel File" and pick any `.xlsx`
  file with the Storage Access Framework. A loading progress bar is shown
  while Apache POI reads the file.
- **Dashboard** — total merchants, Completed, Discrepant, CNIC Verify
  Pending, and the total-volume sum, shown at the top after upload.
- **Filters (all work together)**
  - Search box: Business Name, Mobile Number, QR ID, City, Address1
  - Status chips: All / Completed / Discrepant / CNIC Verify Pending
    (any other `Current_Status` value appears as its own status)
  - City dropdown, JCS dropdown
  - Volume filter: All / Total Volume = 0 / > 0 / ≥ 500
  - The filtered count is shown ("Showing X of Y merchants").
- **Merchant list** — cards with Business Name, City, status chip,
  Total Volume and Mobile. **Tap a card to expand its detail inline**
  (no new screen): QR ID, mobile, address, Raast / Non-Raast / Oct / Sep
  volumes, JCS, RDM, Emp ID, Name, REG Month, Merchant Gender.
- **Export filtered list** — "Download Excel" writes a `.xlsx` with all
  27 original columns in their original order, containing only the
  filtered rows. "Share" opens the Android share sheet (e.g. WhatsApp)
  with that file attached.

## Requirements

- Android Studio (Ladybug or newer recommended)
- JDK 17
- Android SDK with API 36 installed
- `minSdk 29` (Android 10) — `targetSdk 36` (Android 16) — `compileSdk 36`

## Open in Android Studio

1. Open Android Studio → **Open** → select this folder
   (`merchant-data-app`).
2. Let Gradle sync finish (it downloads the Android Gradle Plugin,
   Kotlin and Apache POI from Google / Maven Central — internet needed).
3. Run on a phone or emulator (Android 10 or newer).

## Build the APK

In Android Studio:

**Build → Build App Bundle(s) / APK(s) → Build APK(s)**

The debug APK is then at:

```
app/build/outputs/apk/debug/app-debug.apk
```

Or from the command line (JDK 17 + Android SDK required):

```bash
./gradlew assembleDebug
```

Install that APK on any Android 10–16 phone and share it with friends —
each person uploads their own Excel file in the app.

## How to change the colours

All colours live in one file:

```
app/src/main/res/values/colors.xml
```

Change the values there — for example `emerald_dark`, `emerald`,
`gold`, `gold_light`, `background` — and the whole app changes.
The theme itself is in `app/src/main/res/values/themes.xml`
(`Theme.MerchantDataApp`).

Current theme: **Emerald & Gold** — emerald green header, gold accents,
white cards, large readable text.

## Project layout

```
merchant-data-app/
├── app/
│   ├── build.gradle.kts          # minSdk 29, targetSdk 36, POI deps
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/faisal/merchantdata/
│       │   ├── MainActivity.kt   # upload, dashboard, filters, export
│       │   ├── Merchant.kt       # data model, 27 original columns
│       │   └── MerchantAdapter.kt# merchant cards + inline detail
│       └── res/
│           ├── layout/           # activity_main, item_merchant, stat_card
│           └── values/           # colors.xml, themes.xml, strings.xml
├── build.gradle.kts
├── settings.gradle.kts
└── README.md
```
